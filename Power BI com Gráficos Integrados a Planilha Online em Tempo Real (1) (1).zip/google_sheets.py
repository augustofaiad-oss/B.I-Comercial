import gspread
from google.auth import default
import pandas as pd
from datetime import datetime
import os
import json
from typing import Optional, Dict, Any

class GoogleSheetsService:
    def __init__(self):
        self.client = None
        self.sheet = None
        self.sheet_url = None
        
    def conectar_com_url(self, sheet_url: str) -> bool:
        """
        Conecta com uma planilha do Google Sheets usando URL pública
        """
        try:
            self.sheet_url = sheet_url
            
            # Extrai o ID da planilha da URL
            if '/spreadsheets/d/' in sheet_url:
                sheet_id = sheet_url.split('/spreadsheets/d/')[1].split('/')[0]
            else:
                raise ValueError("URL inválida do Google Sheets")
            
            # Tenta conectar sem autenticação (planilha pública)
            self.client = gspread.service_account()
            self.sheet = self.client.open_by_key(sheet_id)
            
            return True
            
        except Exception as e:
            print(f"Erro ao conectar com Google Sheets: {e}")
            return False
    
    def conectar_com_csv_url(self, csv_url: str) -> bool:
        """
        Conecta com uma planilha exportada como CSV público
        """
        try:
            self.sheet_url = csv_url
            return True
        except Exception as e:
            print(f"Erro ao configurar CSV URL: {e}")
            return False
    
    def obter_dados(self) -> Optional[pd.DataFrame]:
        """
        Obtém os dados da planilha e retorna como DataFrame
        """
        try:
            if not self.sheet_url:
                return None
            
            # Se for URL de CSV público
            if 'export?format=csv' in self.sheet_url or self.sheet_url.endswith('.csv'):
                import requests
                response = requests.get(self.sheet_url)
                if response.status_code == 200:
                    from io import StringIO
                    df = pd.read_csv(StringIO(response.text))
                    return self._processar_dados(df)
            
            # Se for planilha do Google Sheets
            elif self.sheet:
                worksheet = self.sheet.sheet1  # Primeira aba
                dados = worksheet.get_all_records()
                df = pd.DataFrame(dados)
                return self._processar_dados(df)
            
            return None
            
        except Exception as e:
            print(f"Erro ao obter dados: {e}")
            return None
    
    def _processar_dados(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Processa os dados para garantir formato consistente
        """
        try:
            # Mapear possíveis nomes de colunas
            mapeamento_colunas = {
                'data': 'Data',
                'date': 'Data',
                'Data': 'Data',
                'tipo': 'Tipo',
                'type': 'Tipo',
                'Tipo': 'Tipo',
                'categoria': 'Tipo',
                'Categoria': 'Tipo',
                'quantidade': 'Quantidade',
                'qty': 'Quantidade',
                'Quantidade': 'Quantidade',
                'count': 'Quantidade',
                'valor': 'Quantidade'
            }
            
            # Renomear colunas
            df_processado = df.copy()
            for col_original, col_nova in mapeamento_colunas.items():
                if col_original in df_processado.columns:
                    df_processado = df_processado.rename(columns={col_original: col_nova})
            
            # Garantir que as colunas necessárias existam
            colunas_necessarias = ['Data', 'Tipo', 'Quantidade']
            for col in colunas_necessarias:
                if col not in df_processado.columns:
                    print(f"Coluna '{col}' não encontrada. Colunas disponíveis: {list(df_processado.columns)}")
                    return None
            
            # Converter tipos de dados
            df_processado['Data'] = pd.to_datetime(df_processado['Data'], errors='coerce')
            df_processado['Quantidade'] = pd.to_numeric(df_processado['Quantidade'], errors='coerce')
            
            # Remover linhas com dados inválidos
            df_processado = df_processado.dropna(subset=['Data', 'Tipo', 'Quantidade'])
            
            # Mapear tipos para categorias padronizadas
            mapeamento_tipos = {
                'instalacao': 'Instalação',
                'instalação': 'Instalação',
                'installation': 'Instalação',
                'negado': 'Cadastro Negado',
                'denied': 'Cadastro Negado',
                'cancelado': 'Cadastro Cancelado',
                'cancelled': 'Cadastro Cancelado',
                'reanálise': 'Cadastro em Reanálise',
                'reanalise': 'Cadastro em Reanálise',
                'review': 'Cadastro em Reanálise',
                'aprovado': 'Cadastro Aprovado',
                'approved': 'Cadastro Aprovado'
            }
            
            # Aplicar mapeamento de tipos (case insensitive)
            df_processado['Tipo'] = df_processado['Tipo'].str.lower().map(
                lambda x: mapeamento_tipos.get(x, x.title() if isinstance(x, str) else x)
            )
            
            return df_processado
            
        except Exception as e:
            print(f"Erro ao processar dados: {e}")
            return df

# Instância global do serviço
sheets_service = GoogleSheetsService()

def configurar_planilha(sheet_url: str) -> Dict[str, Any]:
    """
    Configura a conexão com a planilha
    """
    try:
        if sheets_service.conectar_com_url(sheet_url):
            return {"success": True, "message": "Planilha configurada com sucesso"}
        elif sheets_service.conectar_com_csv_url(sheet_url):
            return {"success": True, "message": "CSV configurado com sucesso"}
        else:
            return {"success": False, "message": "Erro ao conectar com a planilha"}
    except Exception as e:
        return {"success": False, "message": f"Erro: {str(e)}"}

def obter_dados_planilha() -> Optional[pd.DataFrame]:
    """
    Obtém os dados da planilha configurada
    """
    return sheets_service.obter_dados()

def testar_conexao() -> Dict[str, Any]:
    """
    Testa a conexão com a planilha
    """
    try:
        dados = obter_dados_planilha()
        if dados is not None and not dados.empty:
            return {
                "success": True,
                "message": "Conexão testada com sucesso",
                "linhas": len(dados),
                "colunas": list(dados.columns),
                "amostra": dados.head(3).to_dict('records')
            }
        else:
            return {"success": False, "message": "Nenhum dado encontrado"}
    except Exception as e:
        return {"success": False, "message": f"Erro no teste: {str(e)}"}

