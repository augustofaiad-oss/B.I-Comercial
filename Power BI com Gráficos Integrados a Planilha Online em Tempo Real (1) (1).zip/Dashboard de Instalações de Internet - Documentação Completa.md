# Dashboard de Instalações de Internet - Documentação Completa

**Autor:** Manus AI  
**Data:** 28 de Agosto de 2025  
**Versão:** 1.0

## Sumário Executivo

Este documento apresenta a documentação completa do Dashboard de Instalações de Internet, uma solução web desenvolvida para monitoramento em tempo real de dados relacionados a instalações de internet e processos de cadastro. O sistema foi projetado para integrar-se com planilhas do Google Sheets, oferecendo visualizações interativas e atualizações automáticas dos dados.

O dashboard foi desenvolvido utilizando tecnologias modernas como Flask (Python), Plotly.js para visualizações, Bootstrap para interface responsiva, e integração nativa com Google Sheets API. A solução oferece flexibilidade para trabalhar tanto com dados reais quanto com dados fictícios para demonstração, permitindo uma transição suave durante a implementação.

## 1. Visão Geral do Sistema

### 1.1 Objetivo

O Dashboard de Instalações de Internet foi desenvolvido para atender à necessidade de monitoramento em tempo real de métricas relacionadas a:

- Instalações de internet realizadas
- Cadastros aprovados
- Cadastros negados  
- Cadastros cancelados
- Cadastros em processo de reanálise

### 1.2 Características Principais

O sistema oferece as seguintes funcionalidades principais:

**Visualizações Interativas:** O dashboard apresenta três tipos principais de gráficos - evolução temporal em linha, totais por categoria em barras, e distribuição percentual em formato de pizza. Cada visualização utiliza um esquema de cores consistente que corresponde às categorias definidas na planilha original.

**Integração com Google Sheets:** A solução conecta-se diretamente com planilhas do Google Sheets através de URLs públicas, permitindo que os dados sejam atualizados automaticamente sem necessidade de intervenção manual. O sistema suporta diferentes formatos de URL e realiza mapeamento inteligente de colunas.

**Interface Responsiva:** Desenvolvida com Bootstrap 5, a interface adapta-se automaticamente a diferentes tamanhos de tela, garantindo uma experiência consistente em dispositivos desktop, tablet e mobile.

**Atualização Automática:** O dashboard atualiza os dados automaticamente a cada 30 segundos, garantindo que as informações apresentadas estejam sempre atualizadas. Também oferece a opção de atualização manual através de botão dedicado.

**Modo de Demonstração:** Para facilitar testes e demonstrações, o sistema inclui um gerador de dados fictícios que simula cenários reais de uso, permitindo avaliar a funcionalidade sem necessidade de dados reais.

### 1.3 Arquitetura do Sistema

A arquitetura do sistema segue o padrão MVC (Model-View-Controller) e está organizada da seguinte forma:

**Backend (Flask):** Responsável pela lógica de negócio, integração com Google Sheets, processamento de dados e fornecimento de APIs REST para o frontend.

**Frontend (HTML/CSS/JavaScript):** Interface do usuário desenvolvida com tecnologias web padrão, utilizando Plotly.js para gráficos interativos e Bootstrap para estilização responsiva.

**Integração de Dados:** Módulo especializado para conexão com Google Sheets, incluindo tratamento de diferentes formatos de URL, mapeamento de colunas e processamento de dados.

**Sistema de Configuração:** Interface web dedicada para configuração da integração com planilhas, teste de conexões e alternância entre modos de operação.




## 2. Requisitos Técnicos

### 2.1 Requisitos de Sistema

Para executar o Dashboard de Instalações de Internet, são necessários os seguintes requisitos mínimos:

**Sistema Operacional:** O sistema é compatível com Linux (Ubuntu 22.04 ou superior), Windows 10/11, e macOS 10.15 ou superior. A solução foi desenvolvida e testada primariamente em ambiente Ubuntu 22.04.

**Python:** Versão 3.11 ou superior é recomendada. O sistema utiliza recursos modernos do Python que podem não estar disponíveis em versões anteriores.

**Memória RAM:** Mínimo de 2GB de RAM disponível, com recomendação de 4GB para melhor performance, especialmente ao processar grandes volumes de dados.

**Espaço em Disco:** Aproximadamente 500MB de espaço livre para instalação completa, incluindo dependências e ambiente virtual.

**Conectividade:** Conexão estável com a internet é essencial para integração com Google Sheets e carregamento de bibliotecas CDN utilizadas no frontend.

### 2.2 Dependências Python

O sistema utiliza as seguintes bibliotecas Python principais:

**Flask (2.3.3):** Framework web principal responsável pelo servidor HTTP, roteamento de URLs, e fornecimento das APIs REST. Flask foi escolhido pela sua simplicidade e flexibilidade para desenvolvimento rápido.

**Pandas (2.3.2):** Biblioteca fundamental para manipulação e análise de dados. Utilizada para processamento dos dados da planilha, agregações, e transformações necessárias para as visualizações.

**Plotly (6.3.0):** Biblioteca de visualização de dados que gera gráficos interativos em JavaScript. Responsável pela criação dos gráficos de linha, barras e pizza apresentados no dashboard.

**gspread (6.2.1):** Biblioteca especializada para integração com Google Sheets API. Permite leitura de dados diretamente das planilhas sem necessidade de download manual.

**google-auth (2.40.3):** Sistema de autenticação do Google, utilizado em conjunto com gspread para acesso seguro às planilhas.

**requests (2.32.5):** Biblioteca para requisições HTTP, utilizada para acessar planilhas exportadas como CSV público quando a integração direta não é possível.

### 2.3 Tecnologias Frontend

O frontend utiliza tecnologias web padrão com bibliotecas CDN:

**HTML5 e CSS3:** Estrutura e estilização básica das páginas, seguindo padrões modernos de desenvolvimento web.

**Bootstrap 5.1.3:** Framework CSS responsivo que garante compatibilidade com diferentes dispositivos e navegadores. Fornece componentes pré-estilizados e sistema de grid flexível.

**Plotly.js (latest):** Versão JavaScript da biblioteca Plotly, carregada via CDN para renderização dos gráficos interativos no navegador do usuário.

**Font Awesome 6.0.0:** Biblioteca de ícones vetoriais utilizada para melhorar a experiência visual da interface.

**JavaScript ES6+:** Código JavaScript moderno para interatividade, requisições AJAX, e manipulação do DOM.

### 2.4 Estrutura de Dados

O sistema espera que os dados da planilha sigam uma estrutura específica para funcionamento adequado:

**Coluna Data:** Deve conter datas no formato ISO (YYYY-MM-DD) ou formatos reconhecidos pelo pandas. Esta coluna é utilizada para gráficos de evolução temporal.

**Coluna Tipo:** Deve conter uma das seguintes categorias: "Instalação", "Cadastro Aprovado", "Cadastro Negado", "Cadastro Cancelado", ou "Cadastro em Reanálise". O sistema realiza mapeamento automático de variações destes nomes.

**Coluna Quantidade:** Deve conter valores numéricos representando a quantidade de ocorrências para cada combinação de data e tipo.

O sistema inclui funcionalidades de mapeamento inteligente que reconhecem variações nos nomes das colunas, como "data" vs "Data", "tipo" vs "categoria", "quantidade" vs "valor", garantindo flexibilidade na estrutura da planilha original.


## 3. Guia de Instalação

### 3.1 Preparação do Ambiente

A instalação do Dashboard de Instalações de Internet requer alguns passos preparatórios para garantir que o ambiente esteja adequadamente configurado.

**Verificação do Python:** Primeiro, verifique se o Python 3.11 ou superior está instalado no sistema. No terminal ou prompt de comando, execute `python3 --version` ou `python --version` para confirmar a versão. Se necessário, baixe e instale a versão mais recente do Python através do site oficial python.org.

**Instalação do pip:** Certifique-se de que o gerenciador de pacotes pip está disponível. Normalmente, ele é instalado automaticamente com o Python, mas pode ser verificado executando `pip --version` ou `pip3 --version`.

**Git (Opcional):** Se você planeja clonar o repositório do projeto, certifique-se de que o Git está instalado. Caso contrário, os arquivos podem ser baixados diretamente como arquivo ZIP.

### 3.2 Download e Configuração do Projeto

**Obtenção dos Arquivos:** Baixe todos os arquivos do projeto para um diretório local. A estrutura de diretórios deve ser mantida conforme fornecida, com as pastas `src`, `venv`, e arquivos de configuração na raiz do projeto.

**Criação do Ambiente Virtual:** Navegue até o diretório do projeto e crie um ambiente virtual Python para isolar as dependências. Execute os seguintes comandos:

```bash
cd dashboard_internet
python3 -m venv venv
```

**Ativação do Ambiente Virtual:** Ative o ambiente virtual criado. No Linux/macOS, use `source venv/bin/activate`. No Windows, use `venv\Scripts\activate`. Você deve ver o nome do ambiente virtual no prompt do terminal.

### 3.3 Instalação das Dependências

Com o ambiente virtual ativado, instale todas as dependências necessárias:

**Instalação via requirements.txt:** Execute `pip install -r requirements.txt` para instalar todas as bibliotecas listadas no arquivo de requisitos. Este processo pode levar alguns minutos dependendo da velocidade da conexão com a internet.

**Verificação da Instalação:** Após a instalação, verifique se as principais bibliotecas foram instaladas corretamente executando `pip list` e confirmando a presença de Flask, pandas, plotly, gspread, e outras dependências listadas.

### 3.4 Configuração Inicial

**Teste de Funcionamento:** Execute o servidor de desenvolvimento com `python src/main.py`. O sistema deve iniciar na porta 5000 por padrão. Você deve ver mensagens indicando que o servidor Flask está rodando.

**Acesso à Interface:** Abra um navegador web e acesse `http://localhost:5000`. Você deve ver o dashboard carregando com dados fictícios, confirmando que a instalação foi bem-sucedida.

**Configuração da Planilha:** Acesse `http://localhost:5000/configuracao.html` para configurar a integração com sua planilha do Google Sheets. Siga as instruções na tela para inserir a URL da planilha e testar a conexão.

### 3.5 Solução de Problemas Comuns

**Erro de Porta em Uso:** Se a porta 5000 estiver ocupada, modifique o arquivo `src/main.py` para usar uma porta diferente, como 5001 ou 5002, alterando o parâmetro `port` na função `app.run()`.

**Problemas de Dependências:** Se houver erros durante a instalação das dependências, certifique-se de que o pip está atualizado executando `pip install --upgrade pip` antes de tentar novamente.

**Erro de Permissões:** Em sistemas Linux/macOS, pode ser necessário usar `sudo` para algumas operações, ou configurar permissões adequadas para o usuário atual.

**Problemas de Conectividade:** Verifique se a conexão com a internet está funcionando e se não há firewalls bloqueando as conexões HTTP necessárias para acessar as APIs do Google e CDNs utilizados.


## 4. Configuração da Planilha Google Sheets

### 4.1 Preparação da Planilha

A configuração adequada da planilha Google Sheets é fundamental para o funcionamento correto do dashboard. Este processo envolve tanto a estruturação dos dados quanto a configuração de permissões de acesso.

**Estruturação dos Dados:** A planilha deve conter pelo menos três colunas principais: Data, Tipo e Quantidade. A coluna Data deve seguir um formato consistente, preferencialmente ISO (YYYY-MM-DD), embora o sistema seja capaz de interpretar diversos formatos de data comuns. A coluna Tipo deve conter exatamente uma das categorias reconhecidas pelo sistema: "Instalação", "Cadastro Aprovado", "Cadastro Negado", "Cadastro Cancelado", ou "Cadastro em Reanálise". A coluna Quantidade deve conter valores numéricos inteiros representando o número de ocorrências para cada combinação de data e tipo.

**Organização dos Dados:** Recomenda-se que os dados sejam organizados cronologicamente, com as entradas mais recentes no topo ou na base da planilha, dependendo da preferência. Cada linha deve representar uma única combinação de data, tipo e quantidade. Por exemplo, se em um determinado dia houve 10 instalações e 5 cadastros aprovados, isso deve ser representado em duas linhas separadas na planilha.

**Cabeçalhos das Colunas:** A primeira linha da planilha deve conter os cabeçalhos das colunas. O sistema é flexível quanto aos nomes exatos dos cabeçalhos, reconhecendo variações como "Data" ou "data", "Tipo" ou "categoria", "Quantidade" ou "valor". Esta flexibilidade permite adaptar-se a planilhas existentes sem necessidade de reestruturação completa.

### 4.2 Configuração de Permissões

Para que o dashboard possa acessar os dados da planilha, é necessário configurar as permissões adequadas no Google Sheets.

**Acesso Público:** A forma mais simples de configurar o acesso é tornar a planilha pública para visualização. No Google Sheets, clique no botão "Compartilhar" no canto superior direito da tela. Na janela que se abre, clique em "Alterar para qualquer pessoa com o link" na seção "Acesso geral". Certifique-se de que a permissão está definida como "Visualizador" para manter a segurança dos dados.

**Obtenção da URL:** Após configurar as permissões, copie a URL completa da planilha. Esta URL deve ter o formato `https://docs.google.com/spreadsheets/d/[ID_DA_PLANILHA]/edit#gid=0`. Esta é a URL que será inserida na página de configuração do dashboard.

**Teste de Acesso:** Antes de configurar no dashboard, teste se a URL está funcionando corretamente abrindo-a em uma janela anônima do navegador. Você deve conseguir visualizar a planilha sem fazer login, confirmando que as permissões estão corretas.

### 4.3 Configuração no Dashboard

Com a planilha preparada e as permissões configuradas, o próximo passo é integrar a planilha ao dashboard.

**Acesso à Página de Configuração:** No dashboard, clique no botão "Configurar" no canto superior direito, ou acesse diretamente a URL `/configuracao.html`. Esta página apresenta um formulário para inserir a URL da planilha e outras opções de configuração.

**Inserção da URL:** Cole a URL completa da planilha no campo "URL da Planilha do Google Sheets". Certifique-se de que a URL está completa e correta, incluindo o protocolo `https://` no início.

**Teste da Conexão:** Após inserir a URL, clique em "Configurar Planilha" para estabelecer a conexão. O sistema tentará acessar a planilha e processar os dados. Se a configuração for bem-sucedida, você verá uma mensagem de confirmação com informações sobre os dados encontrados, incluindo o número de linhas e as colunas identificadas.

**Verificação dos Dados:** Use o botão "Testar Conexão" para verificar se os dados estão sendo lidos corretamente. Esta função mostra uma amostra dos dados processados, permitindo confirmar que as colunas foram mapeadas adequadamente e que os tipos de dados estão corretos.

### 4.4 Manutenção e Atualização

Uma vez configurada, a integração com a planilha requer manutenção mínima, mas algumas práticas são recomendadas para garantir funcionamento contínuo.

**Consistência dos Dados:** Mantenha a estrutura da planilha consistente ao adicionar novos dados. Evite alterar os nomes das colunas ou introduzir formatos de data diferentes dos já utilizados. Se mudanças estruturais forem necessárias, teste a integração novamente após as alterações.

**Monitoramento de Erros:** O dashboard inclui tratamento de erros que pode ajudar a identificar problemas com os dados. Se gráficos não estiverem sendo atualizados ou apresentarem dados incorretos, verifique se há erros nos dados da planilha, como datas inválidas ou valores não numéricos na coluna Quantidade.

**Backup dos Dados:** Embora o dashboard não modifique os dados da planilha, é recomendável manter backups regulares da planilha, especialmente se ela contém dados críticos para o negócio. O Google Sheets oferece histórico de versões automático, mas backups adicionais podem ser úteis.

**Atualizações de Permissões:** Periodicamente, verifique se as permissões da planilha ainda estão configuradas corretamente, especialmente se houver mudanças na política de segurança da organização ou se outros usuários relatarem problemas de acesso ao dashboard.


## 5. Guia de Uso do Dashboard

### 5.1 Interface Principal

A interface principal do Dashboard de Instalações de Internet foi projetada para fornecer uma visão abrangente e intuitiva dos dados de instalação e cadastro. A página principal está organizada em seções distintas que trabalham em conjunto para apresentar uma análise completa dos dados.

**Cabeçalho do Dashboard:** A parte superior da página apresenta o título do sistema e uma breve descrição de sua função. No canto superior direito, encontram-se dois botões principais: "Configurar", que leva à página de configuração da planilha, e "Atualizar", que força uma atualização imediata dos dados exibidos. O cabeçalho utiliza um gradiente visual atrativo que estabelece a identidade visual do sistema.

**Cards de Resumo:** Logo abaixo do cabeçalho, uma série de cards apresenta métricas resumidas dos dados. O primeiro card mostra o total geral de todas as categorias, fornecendo uma visão macro do volume de atividades. Os cards subsequentes apresentam os totais individuais para cada categoria: Cadastro Aprovado, Cadastro Cancelado, Cadastro Negado, Cadastro em Reanálise, e Instalação. Cada card utiliza cores específicas que correspondem às cores utilizadas nos gráficos, criando consistência visual em toda a interface.

**Área de Gráficos:** A seção principal da página contém três visualizações interativas dispostas em um layout responsivo. Os gráficos são organizados de forma a maximizar o aproveitamento do espaço da tela, adaptando-se automaticamente a diferentes tamanhos de dispositivo.

### 5.2 Visualizações Disponíveis

O dashboard oferece três tipos principais de visualizações, cada uma projetada para destacar aspectos específicos dos dados.

**Gráfico de Evolução Temporal:** Localizado no canto superior esquerdo da área de gráficos, este gráfico de linha mostra como cada categoria evolui ao longo do tempo. Cada linha representa uma categoria diferente, utilizando cores consistentes com o esquema visual do sistema. O gráfico permite identificar tendências, sazonalidades e padrões temporais nos dados. Os usuários podem interagir com o gráfico passando o mouse sobre os pontos para ver valores específicos, e podem clicar nas legendas para mostrar ou ocultar categorias específicas.

**Gráfico de Totais por Categoria:** Posicionado no canto superior direito, este gráfico de barras verticais apresenta uma comparação direta entre os totais de cada categoria. A altura de cada barra é proporcional ao total de ocorrências da categoria correspondente, facilitando a identificação rápida das categorias com maior ou menor volume. As cores das barras correspondem ao esquema de cores estabelecido para cada categoria, mantendo a consistência visual.

**Gráfico de Distribuição Percentual:** Ocupando a largura completa da página na parte inferior, este gráfico de pizza (ou donut) mostra a distribuição percentual de cada categoria em relação ao total geral. Esta visualização é particularmente útil para entender a proporção relativa de cada tipo de atividade. O gráfico inclui tanto rótulos quanto percentuais, e oferece interatividade através de hover effects que destacam cada seção.

### 5.3 Funcionalidades Interativas

O dashboard incorpora várias funcionalidades interativas projetadas para melhorar a experiência do usuário e facilitar a análise dos dados.

**Atualização Automática:** O sistema atualiza automaticamente os dados a cada 30 segundos, garantindo que as informações apresentadas estejam sempre atualizadas. Esta funcionalidade é especialmente importante em ambientes onde os dados da planilha são atualizados frequentemente. Um indicador na parte inferior da página mostra o timestamp da última atualização, permitindo aos usuários verificar quando os dados foram atualizados pela última vez.

**Atualização Manual:** Além da atualização automática, os usuários podem forçar uma atualização imediata clicando no botão "Atualizar" no cabeçalho. Esta funcionalidade é útil quando se sabe que novos dados foram adicionados à planilha e se deseja ver as mudanças imediatamente.

**Responsividade:** A interface adapta-se automaticamente a diferentes tamanhos de tela, garantindo uma experiência consistente em dispositivos desktop, tablet e mobile. Em telas menores, os gráficos são reorganizados verticalmente para melhor legibilidade, e os cards de resumo ajustam seu layout para otimizar o uso do espaço disponível.

**Indicadores de Status:** Durante o carregamento dos dados, indicadores visuais informam ao usuário que o sistema está processando informações. Estes indicadores incluem spinners de carregamento e mensagens de status que mantêm o usuário informado sobre o progresso das operações.

### 5.4 Interpretação dos Dados

Para maximizar o valor do dashboard, é importante entender como interpretar adequadamente as visualizações apresentadas.

**Análise Temporal:** O gráfico de evolução temporal permite identificar padrões e tendências ao longo do tempo. Picos em determinadas datas podem indicar campanhas de marketing bem-sucedidas ou eventos específicos que impactaram o volume de atividades. Tendências de crescimento ou declínio podem informar decisões estratégicas sobre recursos e processos.

**Comparação de Categorias:** O gráfico de barras facilita a comparação direta entre diferentes tipos de atividades. Um volume alto de cadastros negados em relação aos aprovados pode indicar problemas no processo de aprovação ou critérios muito restritivos. Por outro lado, um alto volume de instalações em relação aos cadastros pode sugerir eficiência no processo de conversão.

**Distribuição Proporcional:** O gráfico de pizza oferece uma perspectiva sobre a distribuição geral das atividades. Uma distribuição equilibrada pode indicar processos estáveis, enquanto concentrações em categorias específicas podem sugerir áreas que requerem atenção ou otimização.

**Métricas de Resumo:** Os cards de resumo fornecem valores absolutos que complementam as visualizações proporcionais. Estes números são úteis para relatórios e para estabelecer metas quantitativas para diferentes aspectos do negócio.


## 6. Arquitetura Técnica Detalhada

### 6.1 Estrutura do Backend

O backend do Dashboard de Instalações de Internet foi desenvolvido seguindo princípios de arquitetura limpa e separação de responsabilidades, garantindo manutenibilidade e escalabilidade do sistema.

**Aplicação Flask Principal:** O arquivo `src/main.py` serve como ponto de entrada da aplicação, configurando o servidor Flask, registrando blueprints, e definindo configurações globais. A aplicação utiliza o padrão de blueprints do Flask para organizar as rotas em módulos lógicos, facilitando a manutenção e expansão futura do sistema. A configuração inclui definições de chave secreta, configuração de banco de dados SQLite para funcionalidades futuras, e configuração de CORS para permitir requisições cross-origin.

**Sistema de Rotas:** As rotas da aplicação estão organizadas em blueprints específicos. O blueprint principal `dashboard_bp` contém todas as rotas relacionadas às funcionalidades do dashboard, incluindo endpoints para obtenção de dados, geração de gráficos, configuração da planilha, e testes de conectividade. Cada rota é documentada com docstrings explicativas e inclui tratamento adequado de erros.

**Serviço de Integração Google Sheets:** O módulo `src/services/google_sheets.py` encapsula toda a lógica de integração com Google Sheets. Esta classe implementa métodos para conexão com planilhas públicas, leitura de dados via API, processamento e normalização dos dados, e tratamento de diferentes formatos de URL. O serviço inclui funcionalidades de fallback que permitem acessar planilhas exportadas como CSV quando a integração direta não é possível.

**Processamento de Dados:** O sistema inclui lógica sofisticada para processamento e normalização dos dados da planilha. Isso inclui mapeamento automático de nomes de colunas, conversão de tipos de dados, tratamento de valores ausentes ou inválidos, e padronização de categorias. O processamento é tolerante a variações nos dados de entrada, aumentando a robustez do sistema.

### 6.2 Estrutura do Frontend

O frontend foi desenvolvido utilizando tecnologias web padrão com foco em performance, usabilidade e responsividade.

**Arquitetura de Páginas:** O sistema consiste em duas páginas principais: o dashboard principal (`index.html`) e a página de configuração (`configuracao.html`). Ambas as páginas seguem uma estrutura HTML5 semântica e utilizam CSS moderno para estilização. O JavaScript é organizado em funções específicas para diferentes funcionalidades, mantendo o código limpo e manutenível.

**Sistema de Visualizações:** As visualizações são geradas utilizando Plotly.js, uma biblioteca JavaScript poderosa para gráficos interativos. Cada tipo de gráfico (linha, barras, pizza) é gerado por uma função específica no backend que retorna dados formatados em JSON compatível com Plotly. O frontend recebe estes dados via requisições AJAX e renderiza os gráficos dinamicamente.

**Gerenciamento de Estado:** O frontend mantém estado mínimo, focando em ser uma interface reativa que reflete o estado atual dos dados no backend. As atualizações são coordenadas através de um sistema de polling que verifica periodicamente por novos dados, e através de atualizações manuais disparadas pelo usuário.

**Responsividade e Acessibilidade:** A interface utiliza Bootstrap 5 para garantir responsividade em diferentes dispositivos. O sistema de grid flexível adapta automaticamente o layout dos gráficos e cards de resumo. Elementos interativos incluem feedback visual adequado, e a interface segue princípios básicos de acessibilidade web.

### 6.3 Fluxo de Dados

O fluxo de dados no sistema segue um padrão bem definido que garante consistência e confiabilidade.

**Origem dos Dados:** Os dados originam-se na planilha Google Sheets configurada pelo usuário. A planilha deve seguir uma estrutura específica com colunas para Data, Tipo e Quantidade. O sistema é flexível quanto aos nomes exatos das colunas, realizando mapeamento automático durante o processamento.

**Ingestão e Processamento:** Quando o sistema precisa atualizar os dados, o serviço Google Sheets é acionado para buscar os dados mais recentes da planilha. Os dados brutos são então processados através de uma série de transformações: normalização de nomes de colunas, conversão de tipos de dados, validação de valores, e enriquecimento com informações adicionais como cores para categorias.

**Agregação e Análise:** Os dados processados passam por etapas de agregação necessárias para as diferentes visualizações. Isso inclui agrupamento por data para gráficos temporais, soma por categoria para gráficos de barras, e cálculo de percentuais para gráficos de pizza. Estas agregações são realizadas utilizando pandas, garantindo performance e precisão.

**Serialização e Entrega:** Os dados agregados são serializados em formato JSON apropriado para cada tipo de visualização. Para gráficos Plotly, isso inclui estruturação dos dados em formato específico com configurações de layout, cores, e interatividade. Os dados são então entregues ao frontend através de endpoints REST específicos.

### 6.4 Tratamento de Erros e Robustez

O sistema implementa múltiplas camadas de tratamento de erros para garantir operação robusta mesmo em condições adversas.

**Validação de Entrada:** Todas as entradas do usuário são validadas tanto no frontend quanto no backend. URLs de planilhas são verificadas quanto ao formato correto, e dados da planilha são validados quanto à estrutura esperada. Mensagens de erro claras são fornecidas quando problemas são detectados.

**Fallbacks e Recuperação:** O sistema inclui múltiplos mecanismos de fallback. Se a integração direta com Google Sheets falhar, o sistema tenta acessar a planilha como CSV público. Se os dados reais não estiverem disponíveis, o sistema automaticamente utiliza dados fictícios para demonstração, garantindo que a interface permaneça funcional.

**Logging e Monitoramento:** Erros e eventos importantes são registrados através do sistema de logging do Python, facilitando diagnóstico e resolução de problemas. O sistema inclui diferentes níveis de log para desenvolvimento e produção.

**Graceful Degradation:** Quando componentes específicos falham, o sistema continua operando com funcionalidade reduzida ao invés de falhar completamente. Por exemplo, se um gráfico específico não pode ser gerado devido a problemas nos dados, os outros gráficos continuam funcionando normalmente.


## 7. Deployment e Produção

### 7.1 Preparação para Produção

A transição do ambiente de desenvolvimento para produção requer considerações específicas para garantir performance, segurança e confiabilidade adequadas.

**Configuração de Ambiente:** Para deployment em produção, é essencial configurar variáveis de ambiente apropriadas. Isso inclui definir `FLASK_ENV=production` para desabilitar o modo debug, configurar uma chave secreta robusta diferente da utilizada em desenvolvimento, e definir configurações específicas de banco de dados se funcionalidades adicionais forem implementadas. Recomenda-se utilizar um arquivo `.env` ou variáveis de ambiente do sistema para gerenciar estas configurações de forma segura.

**Servidor WSGI:** O servidor de desenvolvimento Flask não é adequado para produção. Recomenda-se utilizar um servidor WSGI robusto como Gunicorn ou uWSGI. Para Gunicorn, a configuração típica seria `gunicorn --bind 0.0.0.0:5000 --workers 4 src.main:app`, onde o número de workers deve ser ajustado baseado nos recursos disponíveis do servidor. Para aplicações com maior demanda, considere utilizar um servidor web reverso como Nginx na frente do servidor WSGI.

**Dependências de Produção:** Certifique-se de que todas as dependências estão corretamente especificadas no arquivo `requirements.txt`. Para produção, considere fixar versões específicas das bibliotecas ao invés de usar ranges de versão, garantindo reprodutibilidade do ambiente. Execute `pip freeze > requirements.txt` no ambiente de desenvolvimento para capturar as versões exatas utilizadas.

**Configuração de Rede:** Configure adequadamente as regras de firewall para permitir acesso apenas às portas necessárias. Tipicamente, isso inclui a porta HTTP (80) e HTTPS (443) se SSL estiver configurado. Certifique-se de que o servidor está configurado para aceitar conexões de endereços externos se necessário, modificando o parâmetro `host` na configuração do Flask.

### 7.2 Opções de Deployment

Existem várias opções para fazer o deployment do dashboard, cada uma com suas vantagens e considerações específicas.

**Servidor Dedicado ou VPS:** Para organizações que preferem controle total sobre o ambiente, um servidor dedicado ou VPS oferece máxima flexibilidade. Neste cenário, você tem controle completo sobre o sistema operacional, configurações de rede, e pode instalar qualquer software adicional necessário. Esta opção requer mais conhecimento técnico para configuração e manutenção, mas oferece melhor performance para aplicações com alta demanda.

**Plataformas de Cloud:** Serviços como AWS EC2, Google Cloud Compute Engine, ou Azure Virtual Machines oferecem um meio-termo entre controle e facilidade de uso. Estas plataformas fornecem infraestrutura escalável com ferramentas de monitoramento e backup integradas. A configuração é similar a um servidor dedicado, mas com benefícios adicionais de escalabilidade automática e integração com outros serviços cloud.

**Plataformas PaaS:** Para deployment mais simples, considere plataformas Platform-as-a-Service como Heroku, Railway, ou Render. Estas plataformas simplificam significativamente o processo de deployment, muitas vezes requerendo apenas um comando git push para fazer deploy. Elas automaticamente gerenciam aspectos como scaling, load balancing, e SSL certificates.

**Containerização:** Docker oferece uma abordagem moderna para deployment que garante consistência entre ambientes de desenvolvimento e produção. Crie um Dockerfile que especifica o ambiente Python, instala dependências, e configura a aplicação. Containers podem ser deployados em qualquer plataforma que suporte Docker, incluindo Kubernetes para orquestração em larga escala.

### 7.3 Monitoramento e Manutenção

Um sistema em produção requer monitoramento contínuo e manutenção regular para garantir operação confiável.

**Monitoramento de Performance:** Implemente monitoramento de métricas chave como tempo de resposta, uso de CPU e memória, e taxa de erro. Ferramentas como New Relic, DataDog, ou soluções open-source como Prometheus podem fornecer insights valiosos sobre a performance do sistema. Configure alertas para notificar quando métricas excedem thresholds predefinidos.

**Logging Centralizado:** Configure logging centralizado para facilitar diagnóstico de problemas. Isso inclui logs de aplicação, logs de servidor web, e logs de sistema operacional. Ferramentas como ELK Stack (Elasticsearch, Logstash, Kibana) ou soluções cloud como AWS CloudWatch podem agregar e analisar logs de múltiplas fontes.

**Backup e Recuperação:** Embora o dashboard não armazene dados críticos localmente (os dados residem na planilha Google Sheets), é importante fazer backup das configurações e código da aplicação. Implemente backups automáticos regulares e teste periodicamente os procedimentos de recuperação. Considere utilizar controle de versão (Git) com repositórios remotos como backup adicional do código.

**Atualizações de Segurança:** Mantenha o sistema operacional e todas as dependências atualizadas com patches de segurança. Configure atualizações automáticas para patches críticos de segurança, mas teste atualizações maiores em ambiente de staging antes de aplicar em produção. Monitore vulnerabilidades conhecidas nas dependências Python utilizando ferramentas como Safety ou Snyk.

### 7.4 Escalabilidade e Performance

Para sistemas que precisam suportar múltiplos usuários ou grandes volumes de dados, considerações de escalabilidade são importantes.

**Caching:** Implemente caching para reduzir a carga na API do Google Sheets e melhorar tempos de resposta. Redis ou Memcached podem ser utilizados para cache de dados da planilha, especialmente se os dados não mudam frequentemente. Configure TTL (Time To Live) apropriado baseado na frequência de atualização dos dados.

**Load Balancing:** Para aplicações com alta demanda, configure load balancing para distribuir requisições entre múltiplas instâncias da aplicação. Nginx ou HAProxy podem ser configurados como load balancers, distribuindo tráfego entre múltiplos workers ou servidores.

**Otimização de Dados:** Para planilhas com grandes volumes de dados, considere implementar paginação ou filtros para reduzir a quantidade de dados processados em cada requisição. Implemente agregações no lado do servidor para reduzir a quantidade de dados transferidos para o frontend.

**CDN para Assets Estáticos:** Utilize Content Delivery Networks (CDN) para servir assets estáticos como CSS, JavaScript, e imagens. Isso reduz a carga no servidor principal e melhora tempos de carregamento para usuários geograficamente distribuídos. Serviços como CloudFlare, AWS CloudFront, ou Azure CDN podem ser facilmente integrados.


## 8. Troubleshooting e FAQ

### 8.1 Problemas Comuns de Instalação

Durante o processo de instalação, alguns problemas podem ocorrer dependendo do ambiente e configuração do sistema.

**Erro "Python não encontrado":** Este erro geralmente indica que o Python não está instalado ou não está no PATH do sistema. No Windows, certifique-se de marcar a opção "Add Python to PATH" durante a instalação. No Linux/macOS, o Python pode estar instalado como `python3` ao invés de `python`. Tente usar `python3` e `pip3` ao invés dos comandos sem o sufixo numérico.

**Problemas com pip e dependências:** Se o pip não conseguir instalar algumas dependências, pode ser devido a falta de ferramentas de compilação necessárias para bibliotecas com componentes nativos. No Ubuntu/Debian, instale `build-essential` e `python3-dev`. No CentOS/RHEL, instale `gcc` e `python3-devel`. No Windows, certifique-se de que o Microsoft Visual C++ Build Tools está instalado.

**Erro de permissões:** Em sistemas Unix-like, problemas de permissão podem impedir a instalação de pacotes. Evite usar `sudo pip install` pois isso pode causar problemas de permissão posteriormente. Ao invés disso, use ambientes virtuais que não requerem privilégios administrativos. Se necessário, configure o pip para instalar pacotes no diretório do usuário usando `pip install --user`.

**Conflitos de versão:** Se houver múltiplas versões do Python instaladas, podem ocorrer conflitos. Use `python3 -m venv` ao invés de apenas `venv` para garantir que está usando a versão correta do Python. Verifique qual versão está sendo usada com `python --version` dentro do ambiente virtual ativado.

### 8.2 Problemas de Conectividade com Google Sheets

A integração com Google Sheets pode apresentar desafios específicos relacionados a permissões e formatos de dados.

**Erro "Planilha não encontrada":** Este erro geralmente indica problemas com a URL da planilha ou permissões inadequadas. Verifique se a URL está completa e correta, incluindo o protocolo `https://`. Certifique-se de que a planilha está configurada para acesso público ("Qualquer pessoa com o link pode visualizar"). Teste a URL em uma janela anônima do navegador para confirmar que está acessível sem login.

**Dados não aparecem ou estão incorretos:** Se o dashboard não mostra dados ou mostra dados incorretos, o problema pode estar na estrutura da planilha. Verifique se as colunas têm os nomes corretos (Data, Tipo, Quantidade) ou variações reconhecidas pelo sistema. Certifique-se de que a primeira linha contém cabeçalhos e não dados. Verifique se as datas estão em formato reconhecível e se os valores de quantidade são numéricos.

**Erro de timeout ou conexão lenta:** Se a conexão com Google Sheets está lenta ou apresenta timeouts, pode ser devido ao tamanho da planilha ou problemas de rede. Para planilhas muito grandes, considere filtrar os dados ou usar apenas um subconjunto dos dados mais recentes. Verifique a conectividade com a internet e se não há firewalls bloqueando conexões com Google APIs.

**Problemas com caracteres especiais:** Se a planilha contém caracteres especiais ou acentos que não aparecem corretamente no dashboard, pode ser um problema de encoding. Certifique-se de que a planilha está salva com encoding UTF-8. Se o problema persistir, tente exportar a planilha como CSV e usar a URL do CSV exportado.

### 8.3 Problemas de Performance e Interface

Problemas relacionados à performance do dashboard e comportamento da interface podem afetar a experiência do usuário.

**Dashboard carrega lentamente:** Se o dashboard demora para carregar, verifique primeiro a conectividade com a internet, pois o sistema carrega bibliotecas via CDN. Se a planilha é muito grande, o processamento dos dados pode demorar. Considere otimizar a planilha removendo dados antigos desnecessários ou implementando filtros de data. Verifique se o servidor tem recursos suficientes (CPU e memória) disponíveis.

**Gráficos não aparecem ou aparecem incorretamente:** Se os gráficos não renderizam, verifique se o JavaScript está habilitado no navegador. Problemas com gráficos podem também indicar dados inválidos ou estrutura incorreta. Use as ferramentas de desenvolvedor do navegador (F12) para verificar se há erros JavaScript no console. Certifique-se de que a biblioteca Plotly.js está carregando corretamente verificando a aba Network das ferramentas de desenvolvedor.

**Interface não responsiva em dispositivos móveis:** Se a interface não se adapta corretamente a telas menores, pode ser um problema com o CSS ou JavaScript. Verifique se o viewport meta tag está presente no HTML. Teste em diferentes dispositivos e navegadores para identificar problemas específicos. Certifique-se de que a versão do Bootstrap está carregando corretamente.

**Atualizações automáticas não funcionam:** Se o dashboard não atualiza automaticamente a cada 30 segundos, pode haver problemas com o JavaScript ou conectividade. Verifique o console do navegador para erros JavaScript. Teste a atualização manual para verificar se o problema é específico da atualização automática. Verifique se não há bloqueadores de script ou extensões do navegador interferindo.

### 8.4 Perguntas Frequentes (FAQ)

**Posso usar planilhas do Excel ao invés do Google Sheets?** Atualmente, o sistema é projetado especificamente para Google Sheets. Para usar dados do Excel, você precisaria primeiro importar a planilha para Google Sheets ou exportar como CSV e hospedar o arquivo CSV em um local acessível publicamente.

**Quantos dados o sistema pode processar?** O sistema pode processar planilhas com milhares de linhas, mas a performance pode degradar com volumes muito grandes. Para melhor performance, recomenda-se manter a planilha com dados dos últimos 12-24 meses e arquivar dados mais antigos.

**É possível personalizar as cores dos gráficos?** Sim, as cores podem ser personalizadas modificando o dicionário de cores no arquivo `src/routes/dashboard.py`. Cada categoria tem uma cor específica definida em formato hexadecimal.

**O sistema funciona offline?** Não, o sistema requer conectividade com a internet para acessar a planilha Google Sheets e carregar bibliotecas JavaScript via CDN. Para uso offline, seria necessário modificar o sistema para usar dados locais e bibliotecas locais.

**Posso adicionar novas categorias além das cinco padrão?** Sim, o sistema pode ser estendido para suportar categorias adicionais. Isso requer modificações no código para incluir as novas categorias no mapeamento de cores e na lógica de processamento.

**É possível exportar os gráficos como imagens?** Os gráficos Plotly incluem funcionalidade nativa para exportar como PNG. Os usuários podem clicar no ícone de câmera que aparece quando passam o mouse sobre os gráficos.

**O sistema suporta múltiplas planilhas simultaneamente?** Atualmente, o sistema suporta apenas uma planilha por vez. Para suportar múltiplas planilhas, seria necessário modificar a arquitetura para incluir seleção de fonte de dados.

**Como posso fazer backup dos dados?** Os dados residem na planilha Google Sheets, então o backup deve ser feito através das funcionalidades do Google Sheets. O Google mantém histórico de versões automaticamente, mas backups adicionais podem ser criados fazendo cópias da planilha.

**É possível integrar com outras fontes de dados além do Google Sheets?** Sim, o sistema foi projetado com arquitetura modular que permite adicionar novos provedores de dados. Isso requereria implementar uma nova classe de serviço seguindo a mesma interface da classe Google Sheets existente.

**O sistema é seguro para dados sensíveis?** O sistema acessa apenas planilhas configuradas para acesso público e não armazena dados localmente além de cache temporário. Para dados altamente sensíveis, considere implementar autenticação adicional e criptografia de dados em trânsito.


## 9. Conclusão

O Dashboard de Instalações de Internet representa uma solução completa e robusta para monitoramento em tempo real de métricas relacionadas a instalações de internet e processos de cadastro. Através da integração nativa com Google Sheets e interface web moderna, o sistema oferece uma ferramenta poderosa para análise de dados operacionais.

### 9.1 Benefícios Alcançados

A implementação deste dashboard oferece benefícios significativos para organizações que precisam monitorar e analisar dados de instalação e cadastro. A visualização em tempo real permite identificação rápida de tendências e padrões, facilitando tomadas de decisão baseadas em dados. A interface intuitiva reduz a curva de aprendizado e permite que usuários não técnicos utilizem efetivamente a ferramenta.

A integração com Google Sheets elimina a necessidade de sistemas complexos de importação de dados, permitindo que equipes continuem usando ferramentas familiares para entrada de dados enquanto se beneficiam de visualizações avançadas. A arquitetura modular do sistema facilita manutenção e permite extensões futuras conforme necessidades evoluem.

### 9.2 Considerações Futuras

Embora o sistema atual atenda aos requisitos especificados, existem oportunidades para melhorias e expansões futuras. A implementação de autenticação de usuários permitiria controle de acesso mais granular e personalização por usuário. A adição de filtros temporais interativos permitiria análises mais detalhadas de períodos específicos.

A integração com outras fontes de dados, como APIs de CRM ou sistemas de billing, poderia enriquecer as análises disponíveis. Funcionalidades de alertas automáticos baseados em thresholds configuráveis poderiam proativamente notificar gestores sobre situações que requerem atenção.

### 9.3 Suporte e Manutenção

Para garantir operação contínua e efetiva do sistema, recomenda-se estabelecer procedimentos regulares de manutenção. Isso inclui monitoramento proativo da performance, atualizações regulares de dependências de segurança, e backup das configurações do sistema.

A documentação fornecida neste documento deve ser mantida atualizada conforme modificações são feitas no sistema. Treinamento adequado dos usuários finais garantirá utilização efetiva das funcionalidades disponíveis.

## Apêndices

### Apêndice A: Estrutura de Arquivos

```
dashboard_internet/
├── src/
│   ├── main.py                 # Aplicação Flask principal
│   ├── models/                 # Modelos de dados
│   │   ├── __init__.py
│   │   └── user.py
│   ├── routes/                 # Rotas da aplicação
│   │   ├── __init__.py
│   │   ├── dashboard.py        # Rotas do dashboard
│   │   └── user.py
│   ├── services/               # Serviços de integração
│   │   ├── __init__.py
│   │   └── google_sheets.py    # Integração Google Sheets
│   ├── static/                 # Arquivos estáticos
│   │   ├── index.html          # Dashboard principal
│   │   └── configuracao.html   # Página de configuração
│   └── database/               # Banco de dados
│       └── app.db
├── venv/                       # Ambiente virtual Python
├── requirements.txt            # Dependências Python
├── DOCUMENTACAO.md            # Esta documentação
└── README.md                  # Instruções básicas
```

### Apêndice B: Endpoints da API

| Endpoint | Método | Descrição |
|----------|--------|-----------|
| `/api/dashboard/dados` | GET | Retorna dados brutos da planilha |
| `/api/dashboard/grafico/linha` | GET | Dados para gráfico de evolução temporal |
| `/api/dashboard/grafico/barras` | GET | Dados para gráfico de barras por categoria |
| `/api/dashboard/grafico/pizza` | GET | Dados para gráfico de distribuição percentual |
| `/api/dashboard/resumo` | GET | Métricas resumidas e totais |
| `/api/dashboard/configurar` | POST | Configura URL da planilha |
| `/api/dashboard/testar` | GET | Testa conexão com planilha |
| `/api/dashboard/status` | GET | Status atual da configuração |
| `/api/dashboard/alternar-modo` | GET | Alterna entre dados reais/fictícios |

### Apêndice C: Códigos de Cores das Categorias

| Categoria | Cor Hexadecimal | Cor RGB | Descrição Visual |
|-----------|----------------|---------|------------------|
| Instalação | #2E8B57 | rgb(46, 139, 87) | Verde mar |
| Cadastro Aprovado | #32CD32 | rgb(50, 205, 50) | Verde lima |
| Cadastro Negado | #DC143C | rgb(220, 20, 60) | Vermelho carmesim |
| Cadastro Cancelado | #FF6347 | rgb(255, 99, 71) | Tomate |
| Cadastro em Reanálise | #FFD700 | rgb(255, 215, 0) | Dourado |

### Apêndice D: Exemplo de Estrutura de Dados da Planilha

```csv
Data,Tipo,Quantidade
2025-08-28,Instalação,10
2025-08-28,Cadastro Aprovado,15
2025-08-28,Cadastro Negado,2
2025-08-28,Cadastro Cancelado,1
2025-08-28,Cadastro em Reanálise,3
2025-08-29,Instalação,12
2025-08-29,Cadastro Aprovado,18
2025-08-29,Cadastro Negado,1
2025-08-29,Cadastro Cancelado,0
2025-08-29,Cadastro em Reanálise,2
```

---

**Documento gerado por:** Manus AI  
**Data de criação:** 28 de Agosto de 2025  
**Versão:** 1.0  
**Última atualização:** 28 de Agosto de 2025

