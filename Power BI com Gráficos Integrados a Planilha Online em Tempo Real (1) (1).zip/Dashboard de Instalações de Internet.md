# Dashboard de Instalações de Internet

Um dashboard web interativo para monitoramento em tempo real de instalações de internet e processos de cadastro, com integração nativa ao Google Sheets.

## 🚀 Características Principais

- **Visualizações Interativas**: Gráficos de linha, barras e pizza com dados em tempo real
- **Integração Google Sheets**: Conecta diretamente com planilhas públicas do Google Sheets
- **Interface Responsiva**: Funciona perfeitamente em desktop, tablet e mobile
- **Atualização Automática**: Dados atualizados automaticamente a cada 30 segundos
- **Modo Demonstração**: Inclui dados fictícios para testes e demonstrações

## 📊 Categorias Monitoradas

- Instalações de Internet
- Cadastros Aprovados
- Cadastros Negados
- Cadastros Cancelados
- Cadastros em Reanálise

## 🛠️ Instalação Rápida

### Pré-requisitos
- Python 3.11 ou superior
- pip (gerenciador de pacotes Python)

### Passos de Instalação

1. **Clone ou baixe o projeto**
   ```bash
   cd dashboard_internet
   ```

2. **Crie um ambiente virtual**
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # Linux/macOS
   # ou
   venv\Scripts\activate     # Windows
   ```

3. **Instale as dependências**
   ```bash
   pip install -r requirements.txt
   ```

4. **Execute o servidor**
   ```bash
   python src/main.py
   ```

5. **Acesse o dashboard**
   - Abra seu navegador e vá para: `http://localhost:5000`

## 📋 Configuração da Planilha

### Estrutura Esperada

Sua planilha Google Sheets deve ter as seguintes colunas:

| Data | Tipo | Quantidade |
|------|------|------------|
| 2025-08-28 | Instalação | 10 |
| 2025-08-28 | Cadastro Aprovado | 15 |
| 2025-08-28 | Cadastro Negado | 2 |

### Como Configurar

1. **Prepare sua planilha** no Google Sheets com a estrutura acima
2. **Configure permissões**: Compartilhar → "Qualquer pessoa com o link" → "Visualizador"
3. **Copie a URL** completa da planilha
4. **No dashboard**, clique em "Configurar" e cole a URL
5. **Teste a conexão** para verificar se os dados estão sendo lidos corretamente

## 🎯 Como Usar

### Dashboard Principal
- **Cards de Resumo**: Visualize totais por categoria
- **Gráfico de Evolução**: Acompanhe tendências ao longo do tempo
- **Gráfico de Barras**: Compare totais entre categorias
- **Gráfico de Pizza**: Veja distribuição percentual

### Página de Configuração
- Configure a URL da planilha Google Sheets
- Teste a conexão com os dados
- Alterne entre dados reais e fictícios
- Monitore o status da integração

## 🔧 Funcionalidades Técnicas

- **Backend**: Flask (Python) com APIs REST
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **Gráficos**: Plotly.js para visualizações interativas
- **Integração**: Google Sheets API via gspread
- **Responsividade**: Design adaptável para todos os dispositivos

## 📱 Compatibilidade

- **Navegadores**: Chrome, Firefox, Safari, Edge (versões modernas)
- **Dispositivos**: Desktop, Tablet, Mobile
- **Sistemas**: Windows, macOS, Linux

## 🆘 Solução de Problemas

### Problemas Comuns

**Dashboard não carrega:**
- Verifique se o Python está instalado corretamente
- Certifique-se de que todas as dependências foram instaladas
- Verifique se a porta 5000 não está sendo usada por outro programa

**Planilha não conecta:**
- Verifique se a URL está correta e completa
- Confirme que as permissões estão configuradas como "público"
- Teste a URL em uma janela anônima do navegador

**Gráficos não aparecem:**
- Verifique sua conexão com a internet (bibliotecas carregadas via CDN)
- Certifique-se de que JavaScript está habilitado
- Verifique se os dados da planilha seguem a estrutura esperada

## 📚 Documentação Completa

Para informações detalhadas sobre arquitetura, deployment, e configurações avançadas, consulte o arquivo `DOCUMENTACAO.md`.

## 🤝 Suporte

Para dúvidas ou problemas:
1. Consulte a seção de Troubleshooting na documentação completa
2. Verifique se sua planilha segue a estrutura esperada
3. Teste primeiro com dados fictícios para isolar problemas

## 📄 Licença

Este projeto foi desenvolvido pela Manus AI como solução personalizada para monitoramento de instalações de internet.

---

**Desenvolvido por:** Manus AI  
**Versão:** 1.0  
**Data:** Agosto 2025

