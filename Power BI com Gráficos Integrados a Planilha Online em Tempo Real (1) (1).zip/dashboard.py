from flask import Blueprint, jsonify, request
import pandas as pd
import plotly.graph_objs as go
import plotly.utils
import json
from datetime import datetime, timedelta
import random
from src.services.google_sheets import configurar_planilha, obter_dados_planilha, testar_conexao

dashboard_bp = Blueprint('dashboard', __name__)

# Configuração global da planilha
planilha_configurada = False
usar_dados_ficticios = True

def obter_dados():
    """Obtém dados reais da planilha ou dados fictícios"""
    global usar_dados_ficticios, planilha_configurada
    
    if not usar_dados_ficticios and planilha_configurada:
        try:
            df_real = obter_dados_planilha()
            if df_real is not None and not df_real.empty:
                # Adicionar cores baseadas no tipo (adaptadas para tema escuro)
                cores = {
                    'Instalação': '#68d391',  # Verde claro
                    'Cadastro Negado': '#fc8181',  # Vermelho claro
                    'Cadastro Cancelado': '#f6ad55',  # Laranja claro
                    'Cadastro em Reanálise': '#f6e05e',  # Amarelo claro
                    'Cadastro Aprovado': '#63b3ed'  # Azul claro
                }
                df_real['Cor'] = df_real['Tipo'].map(cores).fillna('#6c757d')
                return df_real
        except Exception as e:
            print(f"Erro ao obter dados reais: {e}")
    
    # Fallback para dados fictícios
    return gerar_dados_ficticios()

@dashboard_bp.route('/configurar', methods=['POST'])
def configurar():
    """Endpoint para configurar a planilha do Google Sheets"""
    global planilha_configurada, usar_dados_ficticios
    
    try:
        data = request.get_json()
        sheet_url = data.get('sheet_url')
        
        if not sheet_url:
            return jsonify({
                'success': False,
                'error': 'URL da planilha é obrigatória'
            }), 400
        
        resultado = configurar_planilha(sheet_url)
        
        if resultado['success']:
            planilha_configurada = True
            usar_dados_ficticios = False
            
            # Testar a conexão
            teste = testar_conexao()
            return jsonify({
                'success': True,
                'message': 'Planilha configurada com sucesso',
                'teste': teste
            })
        else:
            return jsonify(resultado), 400
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@dashboard_bp.route('/testar')
def testar():
    """Endpoint para testar a conexão com a planilha"""
    try:
        resultado = testar_conexao()
        return jsonify(resultado)
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@dashboard_bp.route('/status')
def status():
    """Endpoint para verificar o status da configuração"""
    global planilha_configurada, usar_dados_ficticios
    
    return jsonify({
        'planilha_configurada': planilha_configurada,
        'usando_dados_ficticios': usar_dados_ficticios,
        'timestamp': datetime.now().isoformat()
    })

@dashboard_bp.route('/alternar-modo')
def alternar_modo():
    """Endpoint para alternar entre dados reais e fictícios"""
    global usar_dados_ficticios
    
    usar_dados_ficticios = not usar_dados_ficticios
    
    return jsonify({
        'success': True,
        'usando_dados_ficticios': usar_dados_ficticios,
        'message': f"Modo alterado para: {'Dados Fictícios' if usar_dados_ficticios else 'Dados Reais'}"
    })
def gerar_dados_ficticios():
    categorias = ['Instalação', 'Cadastro Negado', 'Cadastro Cancelado', 'Cadastro em Reanálise', 'Cadastro Aprovado']
    cores = {
        'Instalação': '#68d391',  # Verde claro
        'Cadastro Negado': '#fc8181',  # Vermelho claro
        'Cadastro Cancelado': '#f6ad55',  # Laranja claro
        'Cadastro em Reanálise': '#f6e05e',  # Amarelo claro
        'Cadastro Aprovado': '#63b3ed'  # Azul claro
    }
    
    dados = []
    base_date = datetime.now() - timedelta(days=30)
    
    for i in range(30):
        data_atual = base_date + timedelta(days=i)
        for categoria in categorias:
            quantidade = random.randint(1, 20)
            dados.append({
                'Data': data_atual.strftime('%Y-%m-%d'),
                'Tipo': categoria,
                'Quantidade': quantidade,
                'Cor': cores[categoria]
            })
    
    return pd.DataFrame(dados)

@dashboard_bp.route('/dados')
def obter_dados_endpoint():
    """Endpoint para obter os dados do dashboard"""
    try:
        df = obter_dados()
        return jsonify({
            'success': True,
            'dados': df.to_dict('records')
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@dashboard_bp.route('/grafico/linha')
def grafico_linha():
    """Gráfico de linha mostrando evolução temporal"""
    try:
        df = obter_dados()
        
        fig = go.Figure()
        
        for tipo in df['Tipo'].unique():
            dados_tipo = df[df['Tipo'] == tipo]
            dados_agrupados = dados_tipo.groupby('Data')['Quantidade'].sum().reset_index()
            
            cor = dados_tipo['Cor'].iloc[0]
            
            fig.add_trace(go.Scatter(
                x=dados_agrupados['Data'],
                y=dados_agrupados['Quantidade'],
                mode='lines+markers',
                name=tipo,
                line=dict(color=cor, width=3),
                marker=dict(size=8)
            ))
        
        fig.update_layout(
            title='Evolução Temporal das Categorias',
            xaxis_title='Data',
            yaxis_title='Quantidade',
            hovermode='x unified',
            template='plotly_dark',
            paper_bgcolor='rgba(26, 32, 44, 0.8)',
            plot_bgcolor='rgba(26, 32, 44, 0.6)',
            font=dict(color='#e2e8f0'),
            height=400
        )
        
        return json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@dashboard_bp.route('/grafico/barras')
def grafico_barras():
    """Gráfico de barras com totais por categoria"""
    try:
        df = obter_dados()
        
        totais = df.groupby(['Tipo', 'Cor'])['Quantidade'].sum().reset_index()
        
        fig = go.Figure(data=[
            go.Bar(
                x=totais['Tipo'],
                y=totais['Quantidade'],
                marker_color=totais['Cor'],
                text=totais['Quantidade'],
                textposition='auto',
            )
        ])
        
        fig.update_layout(
            title='Total por Categoria',
            xaxis_title='Categoria',
            yaxis_title='Quantidade Total',
            template='plotly_dark',
            paper_bgcolor='rgba(26, 32, 44, 0.8)',
            plot_bgcolor='rgba(26, 32, 44, 0.6)',
            font=dict(color='#e2e8f0'),
            height=400
        )
        
        return json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@dashboard_bp.route('/grafico/pizza')
def grafico_pizza():
    """Gráfico de pizza com distribuição percentual"""
    try:
        df = obter_dados()
        
        totais = df.groupby(['Tipo', 'Cor'])['Quantidade'].sum().reset_index()
        
        fig = go.Figure(data=[
            go.Pie(
                labels=totais['Tipo'],
                values=totais['Quantidade'],
                marker_colors=totais['Cor'],
                hole=0.3,
                textinfo='label+percent',
                textposition='auto'
            )
        ])
        
        fig.update_layout(
            title='Distribuição Percentual por Categoria',
            template='plotly_dark',
            paper_bgcolor='rgba(26, 32, 44, 0.8)',
            plot_bgcolor='rgba(26, 32, 44, 0.6)',
            font=dict(color='#e2e8f0'),
            height=400
        )
        
        return json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@dashboard_bp.route('/resumo')
def resumo():
    """Endpoint para obter resumo estatístico"""
    try:
        df = obter_dados()
        
        resumo_data = {
            'total_geral': int(df['Quantidade'].sum()),
            'por_categoria': df.groupby('Tipo')['Quantidade'].sum().to_dict(),
            'media_diaria': round(df.groupby('Data')['Quantidade'].sum().mean(), 2),
            'ultima_atualizacao': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        return jsonify({
            'success': True,
            'resumo': resumo_data
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

